Example of using imgui with SFML from https://github.com/eliasdaler/imgui-sfml
