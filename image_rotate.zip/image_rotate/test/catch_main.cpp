#define CATCH_CONFIG_MAIN // This tells the catch header to generate a main

#include "catch.hpp"


